//bolinha
let xBolinha = 300;
let yBolinha = 200;
let dBolinha = 15;
let raio = dBolinha / 2

// velocidade da bolinha

let vYbolinha = 6;
let vXbolinha = 6;

// variaveis da raquete

let xRaquete = 5;
let yRaquete = 150;
let larguraRaquete = 10;
let comprimentoRaquete = 90;

// variaveis do oponente
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let velocidadeYOponente;

let colidiu = false;

//Placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//Sons do jogo
let raquetada;
let ponto;
let trilhaSonora;

//Funções pré-carregadas
function preload(){
  trilhaSonora = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilhaSonora.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisao(xRaquete, yRaquete);
  mostraRaquete();
  mostraRaqueteOponente();
  movimentaRaquete();
  movimentaRaqueteOponente();
  colisaoRaquete();
  verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  mostraPlacar();
  marcaPonto();
}

//Exibe a bolinha
function mostraBolinha() {
  circle(xBolinha, yBolinha, dBolinha);
}

//Movimenta a bolinha
function movimentaBolinha(){
  xBolinha += vXbolinha;
  yBolinha += vYbolinha;
}

//Verifica se houve colisão
function verificaColisao() {
  if(xBolinha + raio > width || xBolinha - raio < 0) {
    vXbolinha *= -1;
  }
    
  if(yBolinha + raio > height || yBolinha - raio < 0) {
    vYbolinha *= -1;
  }
  
}

//Exibe raquete
function mostraRaquete() {
  fill(255, 0, 0) 
  rect(xRaquete,yRaquete , larguraRaquete, comprimentoRaquete);
}

function mostraRaqueteOponente() {
  fill(0, 0, 255);
  rect(xRaqueteOponente,yRaqueteOponente , larguraRaquete, comprimentoRaquete);
}

//Movimenta a raquete
function movimentaRaquete() {
  if (keyIsDown(87)){
    yRaquete -= 10;
  }
  if (keyIsDown(83)){
    yRaquete += 10;
  }
}

//Verifica se houve colisão com a raquete
function colisaoRaquete() {
  if (xBolinha - raio < xRaquete + larguraRaquete && yBolinha - raio < yRaquete + comprimentoRaquete && yBolinha + raio > yRaquete) {
    vXbolinha *= -1;
    raquetada.play();
  }
  
}

function verificaColisaoRaquete(x, y){
  colidiu = collideRectCircle(x,y,larguraRaquete,comprimentoRaquete,xBolinha,yBolinha,raio);
  
  if(colidiu){
    vXbolinha *= -1;
    raquetada.play();
  }
}

//Movimenta a raquete do oponente
function movimentaRaqueteOponente(){
  if (keyIsDown(UP_ARROW)){
    yRaqueteOponente -= 10;
  }
  
  if (keyIsDown(DOWN_ARROW)){
    yRaqueteOponente += 10;
  }
}

//Exibe o placar e marca os pontos
function mostraPlacar(){
  stroke(255);
  textAlign(CENTER);
  textSize(20);
  fill(color(255, 0, 0));
  rect(150, 10, 40, 20)
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(0, 0, 255));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosDoOponente, 470,26);
  
}

function marcaPonto(){
  if(xBolinha > 590){
    meusPontos += 1;
    ponto.play();
  }
  if(xBolinha < 10){
    pontosDoOponente += 1;
    ponto.play();
  }
}